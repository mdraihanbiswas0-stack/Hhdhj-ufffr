#!/usr/bin/env node
/**
 * প্রজেক্ট স্ক্যান করে features.json বানায় ও পরীক্ষা করে — কোন প্যাড, উইজেট, টুল, অনুমতি, নেটিভ মডিউল আছে।
 *   node scripts/inventory.mjs [--out features.json]
 * গুরুতর ফাইল না থাকলে exit 1; বাকি সমস্যা সতর্কতা (::warning::) হিসেবে দেখায়।
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const arg = process.argv.indexOf("--out");
const OUT = arg > 0 ? process.argv[arg + 1] : path.join(ROOT, "features.json");
const J = (...p) => path.join(ROOT, ...p);
const ex = (...p) => fs.existsSync(J(...p));
const rd = (...p) => (ex(...p) ? fs.readFileSync(J(...p), "utf8") : "");
const errors = [], warns = [];

for (const f of ["package.json", "capacitor.config.json", "www/index.html", "scripts/patch-android.mjs", "scripts/make-icons.py", "resources/logo.png"])
  if (!ex(f)) errors.push(`প্রয়োজনীয় ফাইল নেই: ${f}`);

const html = rd("www/index.html");
const pm = html.match(/var PADS=\[(.*?)\];/s);
const cap = (x) => x[0].toUpperCase() + x.slice(1);
const pads = pm ? [...pm[1].matchAll(/\["(\w+)","(tb\d+)","([^"]+)"\]/g)].map((x) => {
  const id = x[1];
  const o = {
    id, label: x[3], tab: x[2],
    tabButton: html.includes(`id="${x[2]}"`),
    logo: ex("android-overlay/res/drawable-nodpi", `pad_${id}.png`),
    widgetClass: ex("android-overlay/java", `Widget${cap(id)}.java`),
    widgetXml: ex("android-overlay/res/xml", `widget_pad_${id}.xml`),
  };
  for (const k of ["tabButton", "logo", "widgetClass", "widgetXml"]) if (!o[k]) warns.push(`প্যাড '${id}': ${k} নেই (autowire নিজে বানাবে, শুধু tabButton নিজে যোগ করতে হয়)`);
  return o;
}) : [];
if (!pads.length) errors.push("index.html-এ PADS তালিকা পাওয়া যায়নি");

const perms = [...rd("scripts/patch-android.mjs").matchAll(/\["android\.permission\.(\w+)"/g)].map((x) => x[1]);
const kt = (dir) => (ex(dir) ? fs.readdirSync(J(dir)).filter((f) => f.endsWith(".kt")) : []);
const toolsSrc = rd("android-overlay/omni/kotlin/Tools.kt").split("enum class Source")[0];
const tools = [...toolsSrc.matchAll(/^\s*([A-Z_]+)\("([^"]+)",\s*Glyph/gm)].map((x) => ({ id: x[1], label: x[2] }));
const searchWidgets = kt("android-overlay/omni/kotlin").filter((f) => /Widget/.test(f)).map((f) => f.replace(".kt", ""));
const modules = ex("android-overlay/modules") ? fs.readdirSync(J("android-overlay/modules")) : [];

const inv = {
  generatedAt: new Date().toISOString(),
  app: JSON.parse(rd("capacitor.config.json") || "{}").appName,
  pads,
  widgets: { padWidgets: pads.map((p) => p.id), wideBar: ex("android-overlay/java/WidgetBar.java"), omniSearchWidgets: searchWidgets },
  nativeModules: { earFlow: kt("android-overlay/kotlin").length, omniFinder: kt("android-overlay/omni/kotlin").length, extraModules: modules },
  omniTools: tools,
  permissions: perms,
  features: [
    "autofill-service", "autofill-save-and-suggest", "notification-per-pad-logo", "native-alarm-reminders",
    "manual-backup-share-drive-zip-with-recordings", "audio-screen-recorder", "voice-recorder", "permission-center",
    "omni-finder-samsung-style-search", "omni-finder-browser", "omni-finder-widget", "colorful-custom-icons-no-emoji", "auto-call-recording",
    "firefly-conversation-mode", "read-aloud-replies", "home-widgets",
  ].filter(Boolean),
};
fs.writeFileSync(OUT, JSON.stringify(inv, null, 2));
console.log(`প্যাড ${pads.length}টি: ${pads.map((p) => p.id).join(", ")}`);
console.log(`অনুমতি ${perms.length}টি; ওমনি-টুল ${tools.length}টি; অতিরিক্ত মডিউল ${modules.length}টি`);
for (const w of warns) console.log(`::warning::${w}`);
for (const e of errors) console.log(`::error::${e}`);
process.exit(errors.length ? 1 : 0);
