#!/usr/bin/env node
/**
 * নতুন প্যাডের জন্য উইজেট নিজে নিজে তৈরি করে (প্রতিটি প্যাডের নিজস্ব উইজেট থাকবেই)।
 * নিয়ম: www/index.html-এর PADS তালিকায় প্যাড থাকলেই হয়। এই স্ক্রিপ্ট দেখে কোন প্যাডের
 *   - লোগো (res/drawable-nodpi/pad_<id>.png)
 *   - উইজেট ক্লাস (java/Widget<Id>.java)
 *   - উইজেট XML (res/xml/widget_pad_<id>.xml) ও নাম (wd_<id>)
 * নেই, সেগুলো বানায়। বানানো প্যাডের তালিকা android-overlay/.autopads.json-এ লেখে (patch-android.mjs পড়ে)।
 */
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const OV = path.join(ROOT, "android-overlay");
const html = fs.readFileSync(path.join(ROOT, "www/index.html"), "utf8");
const m = html.match(/var PADS=\[(.*?)\];/s);
if (!m) { console.log("[autowire] PADS তালিকা পাওয়া যায়নি — বাদ"); process.exit(0); }
const pads = [...m[1].matchAll(/\["(\w+)","tb\d+","([^"]+)"\]/g)].map((x) => ({ id: x[1], label: x[2] }));
const cap = (x) => x[0].toUpperCase() + x.slice(1);
const need = [];
fs.mkdirSync(path.join(OV, "java"), { recursive: true });
fs.mkdirSync(path.join(OV, "res/xml"), { recursive: true });
fs.mkdirSync(path.join(OV, "res/drawable-nodpi"), { recursive: true });
fs.mkdirSync(path.join(OV, "res/values"), { recursive: true });
const known = new Set(["pk", "calc", "biz", "nt", "med", "kf", "cal", "jf", "ear", "omni"]);
const strFile = path.join(OV, "res/values/jn_widget_strings_auto.xml");
let strs = fs.existsSync(strFile) ? fs.readFileSync(strFile, "utf8") : "";
const tpl = fs.readFileSync(path.join(OV, "res/xml/widget_pad_omni.xml"), "utf8");
for (const p of pads) {
  const java = path.join(OV, "java", `Widget${cap(p.id)}.java`);
  const xml = path.join(OV, "res/xml", `widget_pad_${p.id}.xml`);
  const logo = path.join(OV, "res/drawable-nodpi", `pad_${p.id}.png`);
  if (!fs.existsSync(logo)) {
    const r = spawnSync("python3", ["-c", `
from PIL import Image, ImageDraw, ImageFont
import sys,hashlib
h=int(hashlib.md5(sys.argv[1].encode()).hexdigest()[:6],16)
c1=((h>>16)&255//1,(h>>8)&255,h&255); c2=(255-c1[0]//2,255-c1[1]//2,255-c1[2]//2)
S=4;N=256*S;im=Image.new('RGBA',(N,N),(0,0,0,0))
g=Image.new('RGBA',(N,N));px=g.load()
for y in range(N):
  for x in range(N):
    t=(x+y)/(2*N);px[x,y]=tuple(int(c1[i]+(c2[i]-c1[i])*t) for i in range(3))+(255,)
m=Image.new('L',(N,N),0);ImageDraw.Draw(m).ellipse((6*S,6*S,N-6*S,N-6*S),fill=255);im.paste(g,(0,0),m)
d=ImageDraw.Draw(im);d.ellipse((6*S,6*S,N-6*S,N-6*S),outline=(255,255,255,110),width=3*S)
d.ellipse((60*S,60*S,196*S,196*S),outline=(255,255,255,235),width=14*S)
d.rounded_rectangle((104*S,104*S,152*S,152*S),radius=10*S,fill=(255,255,255,235))
im.resize((256,256),Image.LANCZOS).save(sys.argv[2])
`, p.id, logo]);
    if (r.status !== 0) console.log("[autowire] লোগো বানানো যায়নি:", p.id, String(r.stderr));
    else console.log("[autowire] লোগো বানানো হয়েছে:", p.id);
  }
  if (!fs.existsSync(java)) {
    fs.writeFileSync(java, `package __APP_ID__;\n\n/** "${p.id}" (${p.label}) প্যাডের উইজেট — স্বয়ংক্রিয়ভাবে তৈরি */\npublic class Widget${cap(p.id)} extends PadWidgetBase {\n    @Override\n    protected String pad() {\n        return "${p.id}";\n    }\n}\n`);
    console.log("[autowire] উইজেট ক্লাস:", p.id);
  }
  if (!fs.existsSync(xml)) {
    fs.writeFileSync(xml, tpl.replaceAll("omni", p.id));
    console.log("[autowire] উইজেট XML:", p.id);
  }
  if (!known.has(p.id)) {
    need.push(p.id);
    if (!strs.includes(`name="wd_${p.id}"`)) {
      strs = strs.replace("</resources>", "") || '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n';
      if (!strs.includes("<resources>")) strs = '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n' + strs;
      strs += `    <string name="wd_${p.id}">ক্যালকু-ফ্লো · ${p.label}</string>\n    <string name="wd_d_${p.id}">ট্যাপ করলে সরাসরি “${p.label}” প্যাড খুলবে</string>\n</resources>\n`;
    }
  }
}
if (need.length) fs.writeFileSync(strFile, strs.includes("</resources>") ? strs : strs + "</resources>\n");
fs.writeFileSync(path.join(OV, ".autopads.json"), JSON.stringify({ pads: need }, null, 2));
console.log(`[autowire] মোট প্যাড ${pads.length}টি; নতুন অতিরিক্ত ${need.length}টি${need.length ? ": " + need.join(", ") : ""}`);
