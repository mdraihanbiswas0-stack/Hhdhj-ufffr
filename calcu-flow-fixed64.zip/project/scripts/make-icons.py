# অ্যাপ আইকন তৈরি — আপনার লোগো (resources/logo.png) থেকে সব সাইজ বানায়
import os, sys
from PIL import Image, ImageDraw, ImageChops

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "android-overlay", "res")
logo = Image.open(os.path.join(ROOT, "resources", "logo.png")).convert("RGB")  # কালো কোণসহ ১০২৪×১০২৪
S = logo.size[0]

def rounded(img, size, radius_frac=0.22):
    big = img.resize((size, size), Image.LANCZOS).convert("RGBA")
    m = Image.new("L", (size * 4, size * 4), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, size * 4 - 1, size * 4 - 1], radius=int(size * 4 * radius_frac), fill=255)
    big.putalpha(m.resize((size, size), Image.LANCZOS))
    return big

def circle(img, size, inner=0.94):
    c = Image.new("RGBA", (size, size), (0, 0, 0, 255))
    w = int(size * inner)
    c.paste(img.resize((w, w), Image.LANCZOS), ((size - w) // 2, (size - w) // 2))
    m = Image.new("L", (size * 4, size * 4), 0)
    ImageDraw.Draw(m).ellipse([0, 0, size * 4 - 1, size * 4 - 1], fill=255)
    c.putalpha(m.resize((size, size), Image.LANCZOS))
    return c

def adaptive_fg(size):
    # অ্যাডাপটিভ আইকন: ১০৮dp ক্যানভাস, মাঝের ~৬৬dp নিরাপদ এলাকা; ব্যাকগ্রাউন্ড কালো
    c = Image.new("RGBA", (size, size), (0, 0, 0, 255))
    w = int(size * 0.80)
    c.paste(logo.resize((w, w), Image.LANCZOS), ((size - w) // 2, (size - w) // 2))
    return c

dens = {"mdpi": 1, "hdpi": 1.5, "xhdpi": 2, "xxhdpi": 3, "xxxhdpi": 4}
for name, m in dens.items():
    d = os.path.join(out, "mipmap-" + name)
    os.makedirs(d, exist_ok=True)
    sz = int(48 * m)
    rounded(logo, sz).save(os.path.join(d, "ic_launcher.png"))
    circle(logo, sz).save(os.path.join(d, "ic_launcher_round.png"))
    adaptive_fg(int(108 * m)).save(os.path.join(d, "ic_launcher_foreground.png"))
    # নোটিফিকেশনের ছোট আইকন (সাদা সিলুয়েট, ২৪dp)
    sd = os.path.join(out, "drawable-" + name)
    os.makedirs(sd, exist_ok=True)
    n = int(24 * m)
    g = logo.convert("L").resize((n * 4, n * 4), Image.LANCZOS)
    # বাল্বের সাদা অংশ = আইকন; কালো খাঁজ = স্বচ্ছ
    a = g.point(lambda v: 255 if v > 128 else 0).resize((n, n), Image.LANCZOS)
    # কালো ব্যাকগ্রাউন্ড ও চারপাশ বাদ: শুধু বাল্ব+তারা সাদা, বাকি স্বচ্ছ (ইতিমধ্যে কালো=০)
    st = Image.new("RGBA", (n, n), (255, 255, 255, 0))
    st.putalpha(a)
    st = Image.merge("RGBA", (Image.new("L", (n, n), 255),) * 3 + (a,))
    st.save(os.path.join(sd, "ic_stat_icon.png"))

# স্প্ল্যাশ লোগো (নডপিআই) — কালো পর্দার মাঝখানে
nd = os.path.join(out, "drawable-nodpi"); os.makedirs(nd, exist_ok=True)
rounded(logo, 480).save(os.path.join(nd, "splash_logo.png"))

# ওয়েব-এর জন্য
res = os.path.join(ROOT, "resources")
rounded(logo, 512).save(os.path.join(res, "icon-512.png"))
rounded(logo, 192).save(os.path.join(res, "icon-192.png"))
rounded(logo, 64).save(os.path.join(res, "favicon-64.png"))
print("icons ok")
