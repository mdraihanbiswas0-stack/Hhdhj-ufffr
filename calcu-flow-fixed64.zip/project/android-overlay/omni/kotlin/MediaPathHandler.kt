package com.jonaki.search

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.os.Build
import android.os.Environment
import android.util.Base64
import android.util.Size
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Serves small JPEG thumbnails for photos / videos to the page:
 *   https://appassets.androidplatform.net/jmedia/<base64url(file path)>
 * Only files inside shared external storage are served.
 */
class MediaPathHandler : WebViewAssetLoader.PathHandler {

    override fun handle(path: String): WebResourceResponse? {
        return try {
            val raw = Base64.decode(path, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val file = File(String(raw, Charsets.UTF_8)).canonicalFile
            val root = Environment.getExternalStorageDirectory().canonicalFile
            if (!file.path.startsWith(root.path + "/") || !file.isFile) return null
            if (file.path.contains("/Android/data/") || file.path.contains("/Android/obb/")) return null

            val bmp: Bitmap? = when (file.extension.lowercase()) {
                "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic" -> decodeSampled(file)
                "mp4", "mkv", "3gp", "webm", "mov" ->
                    if (Build.VERSION.SDK_INT >= 29) ThumbnailUtils.createVideoThumbnail(file, Size(640, 640), null) else null
                else -> null
            }
            if (bmp == null) return null
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
            WebResourceResponse("image/jpeg", null, ByteArrayInputStream(out.toByteArray()))
        } catch (e: Exception) {
            null
        }
    }

    private fun decodeSampled(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 900 || o.outHeight / s > 900) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return BitmapFactory.decodeFile(f.path, o2)
    }
}
