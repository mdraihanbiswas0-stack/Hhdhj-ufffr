package com.jonaki.search

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import org.json.JSONArray
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader

class OmniActivity : AppCompatActivity() {

    lateinit var web: WebView

    private lateinit var bridge: NativeBridge
    private lateinit var loader: WebViewAssetLoader
    private var pageLoaded = false
    private var pendingWebPerm: PermissionRequest? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var audioCb: ((Boolean) -> Unit)? = null
    private var permCb: ((Boolean) -> Unit)? = null

    // first-run permissions (files + contacts); the page loads after the user answers
    private val startupPerms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { loadPage() }

    // camera / microphone requested by the web page (getUserMedia)
    private val webPerms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            val req = pendingWebPerm
            pendingWebPerm = null
            if (req != null) {
                if (res.values.all { it }) req.grant(req.resources) else req.deny()
            }
        }

    // microphone for the native speech recogniser
    private val audioPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            val cb = audioCb
            audioCb = null
            cb?.invoke(ok)
        }

    // any other optional permission (call log, calendar ...) requested from the Finder settings
    private val genericPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            val cb = permCb
            permCb = null
            cb?.invoke(ok)
        }

    private val chooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
            fileCb = null
        }

    // ছবি তুলে/বেছে ছবিতে কী আছে চেনা (ML Kit) → সেই নাম দিয়ে সার্চ
    private val camLauncher = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        bmp?.let { labels(InputImage.fromBitmap(it, 0)) }
    }
    private val picLauncher = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { runCatching { labels(InputImage.fromFilePath(this, it)) }.onFailure { js("window.__omniLabels&&window.__omniLabels([])") } }
    }

    private fun labels(img: InputImage) {
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(img)
            .addOnSuccessListener { l -> js("window.__omniLabels&&window.__omniLabels(${JSONArray(l.take(3).map { it.text })})") }
            .addOnFailureListener { js("window.__omniLabels&&window.__omniLabels([])") }
    }

    fun labelFrom(source: String) {
        if (source == "camera") {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                requestPerm(Manifest.permission.CAMERA) { ok -> if (ok) runCatching { camLauncher.launch(null) } }
            else runCatching { camLauncher.launch(null) }
        } else runCatching { picLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        bridge = NativeBridge(this)
        setupWebView()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) {
                    web.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        val missing = startupPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) loadPage() else startupPerms.launch(missing.toTypedArray())
    }

    private fun startupPermissions(): List<String> {
        val list = mutableListOf(Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CALENDAR, Manifest.permission.READ_SMS)
        if (Build.VERSION.SDK_INT >= 33) {
            list += Manifest.permission.READ_MEDIA_IMAGES
            list += Manifest.permission.READ_MEDIA_VIDEO
            list += Manifest.permission.READ_MEDIA_AUDIO
        } else {
            list += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return list
    }

    private fun loadPage() {
        if (pageLoaded) return
        pageLoaded = true
        val mode = intent?.getStringExtra(EXTRA_MODE)?.filter { it.isLetter() }.orEmpty()
        intent?.removeExtra(EXTRA_MODE)
        val url = BASE_URL + if (mode.isNotEmpty()) "?mode=$mode" else ""
        web.loadUrl(url)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        loader = WebViewAssetLoader.Builder()
            .setDomain(DOMAIN)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/jmedia/", MediaPathHandler())
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.settings.setSupportMultipleWindows(false)
        web.setBackgroundColor(0xFF020617.toInt())
        web.addJavascriptInterface(bridge, "JonakiNative")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == DOMAIN) return false
                openExternal(u)
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.origin.host != DOMAIN) {
                        request.deny()
                        return@runOnUiThread
                    }
                    val need = mutableListOf<String>()
                    for (r in request.resources) {
                        when (r) {
                            PermissionRequest.RESOURCE_VIDEO_CAPTURE -> need += Manifest.permission.CAMERA
                            PermissionRequest.RESOURCE_AUDIO_CAPTURE -> need += Manifest.permission.RECORD_AUDIO
                        }
                    }
                    val missing = need.filter {
                        ContextCompat.checkSelfPermission(this@OmniActivity, it) != PackageManager.PERMISSION_GRANTED
                    }
                    if (missing.isEmpty()) {
                        request.grant(request.resources)
                    } else {
                        pendingWebPerm?.deny()
                        pendingWebPerm = request
                        webPerms.launch(missing.toTypedArray())
                    }
                }
            }

            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = callback
                return try {
                    chooser.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
        }
    }

    /** Opens tel:, sms:, mailto:, https:// (outside the app) etc. in the matching Android app. */
    fun openExternal(u: Uri) {
        try {
            val i = if (u.scheme == "intent") {
                Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME).apply {
                    selector = null
                    component = null
                }
            } else {
                Intent(Intent.ACTION_VIEW, u)
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "খুলতে পারেনি", Toast.LENGTH_SHORT).show()
        }
    }

    fun requestAudio(cb: (Boolean) -> Unit) {
        audioCb = cb
        audioPerm.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun requestPerm(p: String, cb: (Boolean) -> Unit) {
        permCb = cb
        genericPerm.launch(p)
    }

    fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val mode = intent.getStringExtra(EXTRA_MODE)?.filter { it.isLetter() }.orEmpty()
        intent.removeExtra(EXTRA_MODE)
        if (mode.isNotEmpty() && pageLoaded) {
            web.evaluateJavascript("window.__omniOpen&&window.__omniOpen('$mode')", null)
        }
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        bridge.release()
        web.destroy()
        super.onDestroy()
    }

    companion object {
        const val DOMAIN = "appassets.androidplatform.net"
        const val BASE_URL = "https://$DOMAIN/assets/omni/index.html"
        const val EXTRA_MODE = "omni_mode"
    }
}
