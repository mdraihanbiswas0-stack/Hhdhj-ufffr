package com.omnifinder.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Page(val title: String, val url: String)

/** বুকমার্ক ও ইতিহাস (ইনকগনিটোতে ইতিহাস সংরক্ষণ হয় না)। */
class BrowserStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("omni_browser", Context.MODE_PRIVATE)

    private fun load(k: String): MutableList<Page> {
        val a = runCatching { JSONArray(sp.getString(k, "[]")) }.getOrDefault(JSONArray())
        return (0 until a.length()).map { a.getJSONObject(it).let { o -> Page(o.optString("t"), o.optString("u")) } }.toMutableList()
    }
    private fun save(k: String, l: List<Page>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("t", it.title).put("u", it.url)) }
        sp.edit().putString(k, a.toString()).apply()
    }

    fun bookmarks() = load("bm")
    fun history() = load("hist")
    fun isBookmarked(url: String) = bookmarks().any { it.url == url }

    fun toggleBookmark(p: Page): Boolean {
        val l = bookmarks()
        return if (l.removeAll { it.url == p.url }) { save("bm", l); false } else { l.add(0, p); save("bm", l); true }
    }
    fun removeBookmark(url: String) = save("bm", bookmarks().filter { it.url != url })

    fun addHistory(p: Page) {
        if (p.url.isBlank() || p.url.startsWith("about:")) return
        val l = history().filter { it.url != p.url }.toMutableList()
        l.add(0, p); save("hist", l.take(300))
    }
    fun clearHistory() = save("hist", emptyList())

    // সেটিংস
    var adBlock: Boolean get() = sp.getBoolean("ad", true); set(v) = sp.edit().putBoolean("ad", v).apply()
    var darkWeb: Boolean get() = sp.getBoolean("dark", false); set(v) = sp.edit().putBoolean("dark", v).apply()
    var javaScript: Boolean get() = sp.getBoolean("js", true); set(v) = sp.edit().putBoolean("js", v).apply()
    var textZoom: Int get() = sp.getInt("zoom", 100); set(v) = sp.edit().putInt("zoom", v).apply()
}
