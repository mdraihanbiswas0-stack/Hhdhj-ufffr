package com.jonaki.search

import android.Manifest
import android.appwidget.AppWidgetManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.DocumentsContract
import android.provider.Settings
import android.provider.MediaStore
import android.provider.MediaStore.Files.FileColumns
import android.provider.Telephony
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Exposed to the page as window.JonakiNative (see the bridge shim inside index.html). */
class NativeBridge(private val act: OmniActivity) {

    private val ctx: Context = act.applicationContext
    private var recognizer: SpeechRecognizer? = null

    // ---------------------------------------------------------------- apps
    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun getApps(): String = try {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= 33)
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        else
            pm.queryIntentActivities(intent, 0)

        val seen = HashSet<String>()
        val rows = list
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { it to it.loadLabel(pm).toString() }
            .sortedBy { it.second.lowercase() }
        val arr = JSONArray()
        for ((ri, label) in rows) {
            val pkg = ri.activityInfo.packageName
            if (!seen.add(pkg)) continue
            val ai = ri.activityInfo.applicationInfo
            arr.put(
                JSONObject()
                    .put("id", "app_$pkg")
                    .put("name", label)
                    .put("nameBn", label)
                    .put("packageName", pkg)
                    .put("category", categoryOf(ai, pkg))
                    .put("icon", "Compass")
                    .put("iconBgColor", colorOf(pkg))
                    .put("size", fmtSize(File(ai.sourceDir).length()))
            )
        }
        arr.toString()
    } catch (e: Exception) {
        "[]"
    }

    private fun categoryOf(ai: ApplicationInfo, pkg: String): String {
        val p = pkg.lowercase()
        return when {
            listOf("facebook", "instagram", "twitter", "tiktok", "snapchat", "linkedin", "reddit", "pinterest").any { p.contains(it) } -> "social"
            listOf("whatsapp", "telegram", "messenger", "viber", "imo", "dialer", "contacts", "mms", "messaging", "skype", "gmail", "email").any { p.contains(it) } -> "communication"
            listOf("bkash", "nagad", "rocket", "bank", "wallet", "pay", "finance").any { p.contains(it) } -> "finance"
            Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_SOCIAL -> "social"
            Build.VERSION.SDK_INT >= 26 && (ai.category == ApplicationInfo.CATEGORY_AUDIO ||
                ai.category == ApplicationInfo.CATEGORY_VIDEO || ai.category == ApplicationInfo.CATEGORY_IMAGE) -> "media"
            p.contains("youtube") || p.contains("music") || p.contains("video") || p.contains("gallery") || p.contains("photos") -> "media"
            (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 -> "system"
            else -> "utility"
        }
    }

    private val palette = listOf(
        "#2563eb", "#dc2626", "#16a34a", "#9333ea", "#ea580c",
        "#e11d48", "#0d9488", "#4f46e5", "#ca8a04", "#475569"
    )

    private fun colorOf(key: String): String = palette[(key.hashCode() and 0x7fffffff) % palette.size]

    @JavascriptInterface
    fun launchApp(pkg: String) {
        act.runOnUiThread {
            try {
                val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    act.startActivity(i)
                } else {
                    Toast.makeText(ctx, "অ্যাপটি চালু করা যায়নি", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(ctx, "অ্যাপটি চালু করা যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // --------------------------------------------------------------- files
    @JavascriptInterface
    fun searchFiles(q: String, cat: String): String = try {
        val base = MediaStore.Files.getContentUri("external")
        val proj = arrayOf(FileColumns._ID, FileColumns.DISPLAY_NAME, FileColumns.SIZE, FileColumns.DATE_MODIFIED, FileColumns.MIME_TYPE, FileColumns.DATA)
        val has = q.isNotBlank()
        val base0 = "${FileColumns.SIZE}>0 AND ${FileColumns.DISPLAY_NAME} IS NOT NULL"
        val like = if (has) " AND (${FileColumns.DISPLAY_NAME} LIKE ? OR ${FileColumns.DATA} LIKE ?)" else ""
        val args: Array<String>? = if (has) arrayOf("%${q.trim()}%", "%${q.trim()}%") else null
        // documents are not "media" on Android 10+, so a second pass without the media filter
        val arr = JSONArray()
        val ids = HashSet<Long>()
        val queries = listOf(
            "$base0 AND ${FileColumns.MEDIA_TYPE}!=${FileColumns.MEDIA_TYPE_NONE}$like",
            "$base0 AND ${FileColumns.MEDIA_TYPE}=${FileColumns.MEDIA_TYPE_NONE}$like"
        )
        for (s in queries) {
            val b = Bundle().apply {
                putString(android.content.ContentResolver.QUERY_ARG_SQL_SELECTION, s)
                if (args != null) putStringArray(android.content.ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args)
                putString(android.content.ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "${FileColumns.DATE_MODIFIED} DESC")
                putInt(android.content.ContentResolver.QUERY_ARG_LIMIT, 250)
            }
            try {
                ctx.contentResolver.query(base, proj, b, null)?.use { c ->
                    while (c.moveToNext() && arr.length() < 400) {
                        val id = c.getLong(0)
                        if (!ids.add(id)) continue
                        val name = c.getString(1) ?: continue
                        val path = c.getString(5) ?: ""
                        if (path.contains("/Android/data/") || path.contains("/Android/obb/") || path.contains("/.")) continue
                        val category = categoryOfFile(name, c.getString(4) ?: "") ?: continue
                        if (cat != "all" && cat.isNotEmpty() && cat != category) continue
                        val ext = name.substringAfterLast('.', "").lowercase()
                        arr.put(
                            JSONObject()
                                .put("id", "f$id")
                                .put("name", name)
                                .put("category", category)
                                .put("size", fmtSize(c.getLong(2)))
                                .put("updatedAt", bn(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(c.getLong(3) * 1000))))
                                .put("path", path.replace("/storage/emulated/0", "/Internal Storage"))
                                .put("tags", JSONArray(listOf(ext, category).filter { it.isNotEmpty() }))
                                .put("fp", path)
                                .put("cu", ContentUris.withAppendedId(base, id).toString())
                        )
                    }
                }
            } catch (e: Exception) { /* ignore this pass */ }
        }
        arr.toString()
    } catch (e: Exception) {
        "[]"
    }

    private fun categoryOfFile(name: String, mime: String): String? {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            mime.startsWith("image/") -> "photo"
            mime.startsWith("video/") -> "video"
            mime.startsWith("audio/") -> "audio"
            ext == "apk" || mime == "application/vnd.android.package-archive" -> "apk"
            ext in setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "csv", "odt", "rtf") -> "document"
            else -> null
        }
    }

    @JavascriptInterface
    fun openFile(fp: String, cu: String) {
        act.runOnUiThread {
            try {
                val uri = if (cu.isNotEmpty()) Uri.parse(cu) else return@runOnUiThread
                val ext = MimeTypeMap.getFileExtensionFromUrl(fp.replace(" ", "_"))
                val mime = ctx.contentResolver.getType(uri)
                    ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase())
                    ?: "*/*"
                val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                act.startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(ctx, "ফাইলটি খোলার অ্যাপ পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ------------------------------------------------------------ contacts
    @JavascriptInterface
    fun searchContacts(q: String): String = try {
        val has = q.isNotBlank()
        val c = ctx.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER),
            if (has) "${Phone.DISPLAY_NAME} LIKE ? OR ${Phone.NUMBER} LIKE ?" else null,
            if (has) arrayOf("%${q.trim()}%", "%${q.trim()}%") else null,
            "${Phone.DISPLAY_NAME} COLLATE LOCALIZED ASC"
        )
        val map = LinkedHashMap<Long, JSONObject>()
        c?.use {
            while (it.moveToNext() && map.size < 300) {
                val id = it.getLong(0)
                val name = it.getString(1) ?: continue
                val num = it.getString(2) ?: continue
                val o = map[id]
                if (o == null) {
                    map[id] = JSONObject().put("id", "c$id").put("name", name).put("phone", num)
                        .put("avatarColor", colorOf(name))
                } else if (!o.has("secondaryPhone") && digits(o.getString("phone")) != digits(num)) {
                    o.put("secondaryPhone", num)
                }
            }
        }
        JSONArray(map.values.toList()).toString()
    } catch (e: Exception) {
        "[]"
    }

    private fun digits(s: String) = s.filter { it.isDigit() }

    @JavascriptInterface
    fun addContact(name: String, phone: String, relationship: String) {
        act.runOnUiThread {
            try {
                val i = Intent(ContactsContract.Intents.Insert.ACTION).apply {
                    type = ContactsContract.Contacts.CONTENT_TYPE
                    putExtra(ContactsContract.Intents.Insert.NAME, name)
                    putExtra(ContactsContract.Intents.Insert.PHONE, phone)
                    if (relationship.isNotBlank()) putExtra(ContactsContract.Intents.Insert.NOTES, relationship)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                act.startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(ctx, "কন্টাক্ট অ্যাপ খোলা যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ------------------------------------------------------------- storage
    @JavascriptInterface
    fun storageText(): String = try {
        val st = StatFs(Environment.getExternalStorageDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong
        val used = total - st.availableBlocksLong * st.blockSizeLong
        fun gb(b: Long) = String.format(Locale.US, "%.1f", b / 1073741824.0)
        bn("${gb(used)} GB ব্যবহৃত / ${gb(total)} GB")
    } catch (e: Exception) {
        ""
    }

    // ----------------------------------------------------------- clipboard
    @JavascriptInterface
    fun getClipboard(): String = try {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString() ?: ""
    } catch (e: Exception) {
        ""
    }

    @JavascriptInterface
    fun setClipboard(text: String) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("OmniFinder", text))
        } catch (e: Exception) { /* ignore */ }
    }

    // -------------------------------------------------------------- speech
    @JavascriptInterface
    fun startSpeech(lang: String) {
        act.runOnUiThread {
            if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
                speech("error", "", false, "service-not-allowed")
                speech("end", "", false, "")
                return@runOnUiThread
            }
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                beginSpeech(lang)
            } else {
                act.requestAudio { ok ->
                    if (ok) {
                        beginSpeech(lang)
                    } else {
                        speech("error", "", false, "not-allowed")
                        speech("end", "", false, "")
                    }
                }
            }
        }
    }

    private fun beginSpeech(lang: String) {
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = speech("start", "", false, "")
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) speech("result", t, false, "")
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) speech("result", t, true, "")
                speech("end", "", false, "")
            }

            override fun onError(error: Int) {
                val e = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "no-speech"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "not-allowed"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "network"
                    SpeechRecognizer.ERROR_AUDIO -> "audio-capture"
                    else -> "aborted"
                }
                speech("error", "", false, e)
                speech("end", "", false, "")
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.ifEmpty { "bn-BD" })
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        r.startListening(i)
    }

    @JavascriptInterface
    fun stopSpeech() {
        act.runOnUiThread { try { recognizer?.stopListening() } catch (e: Exception) { /* ignore */ } }
    }

    private fun speech(type: String, text: String, isFinal: Boolean, err: String) {
        act.js("window.__jnSpeech&&window.__jnSpeech(${JSONObject.quote(type)},${JSONObject.quote(text)},$isFinal,${JSONObject.quote(err)})")
    }

    fun release() {
        try { recognizer?.destroy() } catch (e: Exception) { /* ignore */ }
        recognizer = null
    }

    // -------------------------------------------------------------- widget
    /** Asks the launcher to pin the OmniFinder search-bar widget to the home screen. */
    @JavascriptInterface
    fun pinWidget(): Boolean = try {
        val awm = AppWidgetManager.getInstance(ctx)
        if (Build.VERSION.SDK_INT >= 26 && awm.isRequestPinAppWidgetSupported) {
            awm.requestPinAppWidget(ComponentName(ctx, OmniFinderWidget::class.java), null, null)
        } else {
            false
        }
    } catch (e: Exception) {
        false
    }


    // ------------------------------------------------- finder: system actions
    /** Opens an Android settings screen (only android.settings.* actions or the wallpaper picker). */
    @JavascriptInterface
    fun openSettings(action: String) {
        act.runOnUiThread {
            val ok = action.startsWith("android.settings.") || action == Intent.ACTION_SET_WALLPAPER
            try {
                act.startActivity(Intent(if (ok) action else Settings.ACTION_SETTINGS))
            } catch (e: Exception) {
                try {
                    act.startActivity(Intent(Settings.ACTION_SETTINGS))
                } catch (e2: Exception) {
                    Toast.makeText(ctx, "সেটিংস খোলা যায়নি", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @JavascriptInterface
    fun openAppInfo(pkg: String) {
        act.runOnUiThread {
            try {
                act.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null)))
            } catch (e: Exception) { /* ignore */ }
        }
    }

    @JavascriptInterface
    fun uninstallApp(pkg: String) {
        act.runOnUiThread {
            try {
                act.startActivity(Intent(Intent.ACTION_DELETE, Uri.fromParts("package", pkg, null)))
            } catch (e: Exception) {
                Toast.makeText(ctx, "আনইনস্টল করা যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun openUrl(url: String) {
        if (url.startsWith("https://") || url.startsWith("http://")) {
            act.runOnUiThread { act.openExternal(Uri.parse(url)) }
        }
    }

    /** Opens the folder that contains (or is) [path] in the system Files app. */
    @JavascriptInterface
    fun openFolder(path: String) {
        act.runOnUiThread {
            try {
                val f = File(path)
                val dir = if (f.isDirectory) f else f.parentFile ?: return@runOnUiThread
                val root = Environment.getExternalStorageDirectory().path
                val rel = dir.path.removePrefix(root).trimStart('/')
                val uri = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:$rel")
                act.startActivity(
                    Intent(Intent.ACTION_VIEW).setDataAndType(uri, DocumentsContract.Document.MIME_TYPE_DIR)
                )
            } catch (e: Exception) {
                Toast.makeText(ctx, "ফোল্ডার খোলা যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun setAlarm(hour: Int, minute: Int) {
        act.runOnUiThread {
            try {
                act.startActivity(
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, hour)
                        .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                )
            } catch (e: Exception) {
                Toast.makeText(ctx, "ঘড়ি অ্যাপ পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun setTimer(seconds: Int) {
        act.runOnUiThread {
            try {
                act.startActivity(
                    Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                )
            } catch (e: Exception) {
                Toast.makeText(ctx, "ঘড়ি অ্যাপ পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------------------------------------------- finder: web suggestions
    /** Google search suggestions; the answer is pushed to window.__jnSuggest(id, [..]). */
    @JavascriptInterface
    fun webSuggest(id: Int, q: String) {
        thread {
            var out = "[]"
            try {
                val u = URL("https://suggestqueries.google.com/complete/search?client=firefox&hl=bn&q=" + URLEncoder.encode(q, "UTF-8"))
                val c = u.openConnection() as HttpURLConnection
                c.connectTimeout = 3000
                c.readTimeout = 3000
                val txt = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                out = JSONArray(txt).getJSONArray(1).toString()
                c.disconnect()
            } catch (e: Exception) { /* offline -> empty list */ }
            act.js("window.__jnSuggest&&window.__jnSuggest($id,$out)")
        }
    }

    // ------------------------------------------- finder: call log & calendar
    @JavascriptInterface
    fun searchCalls(q: String): String = try {
        val has = q.isNotBlank()
        val arr = JSONArray()
        val fmt = SimpleDateFormat("d MMM, hh:mm a", Locale("bn", "BD"))
        ctx.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
            if (has) "${CallLog.Calls.CACHED_NAME} LIKE ? OR ${CallLog.Calls.NUMBER} LIKE ?" else null,
            if (has) arrayOf("%${q.trim()}%", "%${q.trim()}%") else null,
            "${CallLog.Calls.DATE} DESC"
        )?.use { c ->
            while (c.moveToNext() && arr.length() < 30) {
                val type = when (c.getInt(2)) {
                    CallLog.Calls.INCOMING_TYPE -> "incoming"
                    CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                    else -> "missed"
                }
                arr.put(
                    JSONObject()
                        .put("number", c.getString(0) ?: "")
                        .put("name", c.getString(1) ?: "")
                        .put("type", type)
                        .put("date", fmt.format(Date(c.getLong(3))))
                )
            }
        }
        arr.toString()
    } catch (e: Exception) {
        "[]"
    }

    @JavascriptInterface
    fun searchCalendar(q: String): String = try {
        val arr = JSONArray()
        val fmt = SimpleDateFormat("d MMM yyyy, hh:mm a", Locale("bn", "BD"))
        ctx.contentResolver.query(
            CalendarContract.Events.CONTENT_URI,
            arrayOf(CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART, CalendarContract.Events.EVENT_LOCATION),
            "${CalendarContract.Events.TITLE} LIKE ? AND ${CalendarContract.Events.DELETED}=0",
            arrayOf("%${q.trim()}%"),
            "${CalendarContract.Events.DTSTART} DESC"
        )?.use { c ->
            while (c.moveToNext() && arr.length() < 20) {
                arr.put(
                    JSONObject()
                        .put("title", c.getString(0) ?: "")
                        .put("date", fmt.format(Date(c.getLong(1))))
                        .put("place", c.getString(2) ?: "")
                )
            }
        }
        arr.toString()
    } catch (e: Exception) {
        "[]"
    }

    // ---------------------------------------------------- finder: permissions
    private fun permOf(name: String): String? = when (name) {
        "calls" -> Manifest.permission.READ_CALL_LOG
        "calendar" -> Manifest.permission.READ_CALENDAR
        "contacts" -> Manifest.permission.READ_CONTACTS
        "camera" -> Manifest.permission.CAMERA
        "sms" -> Manifest.permission.READ_SMS
        "audio" -> Manifest.permission.RECORD_AUDIO
        else -> null
    }

    @JavascriptInterface
    fun hasPermission(name: String): Boolean {
        val p = permOf(name) ?: return false
        return ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    }

    @JavascriptInterface
    fun requestPermission(name: String) {
        val p = permOf(name) ?: return
        act.runOnUiThread {
            act.requestPerm(p) { ok ->
                act.js("window.__jnPerm&&window.__jnPerm(${JSONObject.quote(name)},$ok)")
            }
        }
    }


    // ============ ওমনি-ফাইন্ডার: অতিরিক্ত ক্ষমতা (এসএমএস, ব্রাউজার, টর্চ, QR, ছবি-সার্চ, সব-ফাইল) ============
    @JavascriptInterface
    fun searchSms(q: String): String = try {
        val arr = JSONArray()
        val t = q.trim()
        if (t.isNotEmpty() && ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
            val fmt = SimpleDateFormat("d MMM, hh:mm a", Locale("bn", "BD"))
            ctx.contentResolver.query(
                Telephony.Sms.CONTENT_URI, arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE),
                "${Telephony.Sms.BODY} LIKE ? OR ${Telephony.Sms.ADDRESS} LIKE ?", arrayOf("%$t%", "%$t%"), "${Telephony.Sms.DATE} DESC"
            )?.use { c ->
                while (c.moveToNext() && arr.length() < 30) {
                    arr.put(JSONObject().put("address", c.getString(0) ?: "").put("body", c.getString(1) ?: "")
                        .put("date", fmt.format(Date(c.getLong(2)))).put("sent", c.getInt(3) == Telephony.Sms.MESSAGE_TYPE_SENT))
                }
            }
        }
        arr.toString()
    } catch (e: Exception) { "[]" }

    /** ইন-অ্যাপ ব্রাউজারের বুকমার্ক ও ইতিহাসে খোঁজা */
    @JavascriptInterface
    fun searchBrowser(q: String): String = try {
        val t = q.trim().lowercase()
        val st = com.omnifinder.app.BrowserStore(ctx)
        val arr = JSONArray()
        fun add(p: com.omnifinder.app.Page, kind: String) {
            if (arr.length() < 30 && (p.title + " " + p.url).lowercase().contains(t))
                arr.put(JSONObject().put("title", p.title.ifBlank { p.url }).put("url", p.url).put("kind", kind))
        }
        if (t.isNotEmpty()) { st.bookmarks().forEach { add(it, "bookmark") }; st.history().forEach { add(it, "history") } }
        arr.toString()
    } catch (e: Exception) { "[]" }

    /** ট্যাব, ইনকগনিটো, বুকমার্ক, ডার্ক-মোডসহ নিজস্ব ব্রাউজার */
    @JavascriptInterface
    fun openBrowser(url: String) {
        act.runOnUiThread {
            try {
                act.startActivity(Intent(act, com.omnifinder.app.BrowserActivity::class.java).putExtra("url", url))
            } catch (e: Exception) { Toast.makeText(act, "ব্রাউজার খোলা যায়নি", Toast.LENGTH_SHORT).show() }
        }
    }

    private var torchState = false
    private fun torchId(cm: CameraManager): String? = try {
        cm.cameraIdList.firstOrNull { id ->
            val ch = cm.getCameraCharacteristics(id)
            ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true && ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    } catch (e: Exception) { null }

    @JavascriptInterface
    fun torch(on: Boolean): Boolean = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = torchId(cm)
        if (id == null) { act.runOnUiThread { Toast.makeText(act, "এই ফোনে টর্চ (ফ্ল্যাশ) নেই", Toast.LENGTH_SHORT).show() }; false }
        else { cm.setTorchMode(id, on); torchState = on; true }
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun isTorchOn(): Boolean = torchState

    @JavascriptInterface
    fun scanQr() {
        act.runOnUiThread {
            try {
                com.google.mlkit.vision.codescanner.GmsBarcodeScanning.getClient(act).startScan()
                    .addOnSuccessListener { b -> act.js("window.__omniQr&&window.__omniQr(${JSONObject.quote(b.rawValue ?: "")})") }
                    .addOnFailureListener { act.js("window.__omniQr&&window.__omniQr('')") }
            } catch (e: Exception) { act.js("window.__omniQr&&window.__omniQr('')") }
        }
    }

    /** source = camera | gallery → ছবিতে কী আছে চিনে তার নাম দিয়ে সার্চ */
    @JavascriptInterface
    fun imageSearch(source: String) { act.runOnUiThread { act.labelFrom(source) } }

    @JavascriptInterface
    fun hasAllFiles(): Boolean = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    @JavascriptInterface
    fun requestAllFiles() {
        act.runOnUiThread {
            try {
                val i = if (Build.VERSION.SDK_INT >= 30)
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                act.startActivity(i)
            } catch (e: Exception) {}
        }
    }

    // ------------------------------------------------------------- helpers
    private fun fmtSize(b: Long): String = when {
        b >= 1073741824L -> String.format(Locale.US, "%.1f GB", b / 1073741824.0)
        b >= 1048576L -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%d KB", maxOf(1L, b / 1024))
    }

    private fun bn(s: String): String =
        s.map { if (it in '0'..'9') '০' + (it - '0') else it }.joinToString("")
}
