package com.earflow.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** ফোন চালু বা অ্যাপ আপডেটের পর অটো কল-রেকর্ডার নিজে চালু করে (বন্ধ না করা থাকলে) */
class EarBootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (!ctx.getSharedPreferences("ef", Context.MODE_PRIVATE).getBoolean("auto", true)) return
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, CallRecordService::class.java).setAction("IDLE"))
        } catch (_: Exception) {}
    }
}
