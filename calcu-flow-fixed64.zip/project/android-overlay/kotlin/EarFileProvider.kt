package com.earflow.app

import androidx.core.content.FileProvider

// Capacitor-এর নিজস্ব FileProvider-এর সাথে ম্যানিফেস্ট-সংঘাত এড়াতে আলাদা ক্লাস
class EarFileProvider : FileProvider()
