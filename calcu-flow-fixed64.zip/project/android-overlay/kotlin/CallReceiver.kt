package com.earflow.app

import android.content.*
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

class CallReceiver : BroadcastReceiver() {
    companion object {
        private var lastState = TelephonyManager.CALL_STATE_IDLE
        private var incoming = false
        private var number = ""
        private var recording = false
        @JvmStatic fun lastNumber(): String = number
        @JvmStatic fun lastIncoming(): Boolean = incoming
    }

    private fun send(ctx: Context, act: String) {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, CallRecordService::class.java).apply {
                action = act
                putExtra("number", number)
                putExtra("incoming", incoming)
            })
        } catch (_: Exception) {}
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        if (!ctx.getSharedPreferences("ef", Context.MODE_PRIVATE).getBoolean("auto", true)) return
        if (intent.action == Intent.ACTION_NEW_OUTGOING_CALL) {
            number = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER) ?: ""
            incoming = false
            return
        }
        val st = when (intent.getStringExtra(TelephonyManager.EXTRA_STATE)) {
            TelephonyManager.EXTRA_STATE_RINGING -> TelephonyManager.CALL_STATE_RINGING
            TelephonyManager.EXTRA_STATE_OFFHOOK -> TelephonyManager.CALL_STATE_OFFHOOK
            else -> TelephonyManager.CALL_STATE_IDLE
        }
        @Suppress("DEPRECATION")
        val num = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        if (st == TelephonyManager.CALL_STATE_RINGING) {
            incoming = true
            if (!num.isNullOrEmpty()) number = num
        }
        if (st == lastState) return

        when (st) {
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                if (lastState != TelephonyManager.CALL_STATE_RINGING) incoming = false
                if (!recording) { recording = true; send(ctx, "START") }
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                if (recording) { recording = false; send(ctx, "STOP") }
                number = ""
            }
        }
        lastState = st
    }
}
