package __APP_ID__;

/** "nt" প্যাডের উইজেট */
public class WidgetNt extends PadWidgetBase {
    @Override
    protected String pad() {
        return "nt";
    }
}
