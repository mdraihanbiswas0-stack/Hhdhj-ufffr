package __APP_ID__;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/**
 * এক-প্যাডের উইজেট (শুধু সেই প্যাডের লোগো)। ট্যাপ করলে সরাসরি ওই প্যাডে যায়।
 * ক্যালেন্ডার-উইজেট প্রতিদিনের তারিখ ও বার দেখায়, তাই তারিখ/সময়/টাইমজোন বদলালে নতুন করে আঁকে।
 */
public abstract class PadWidgetBase extends AppWidgetProvider {

    protected abstract String pad();

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) {
            try {
                mgr.updateAppWidget(id, build(ctx));
            } catch (Throwable ignored) {
            }
        }
    }

    private RemoteViews build(Context ctx) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_pad);
        PadWidgets.bindLogo(ctx, rv, R.id.wp_img, pad(), PadWidgets.now());
        return rv;
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        try {
            String a = intent == null ? null : intent.getAction();
            if (a == null) return;
            if (Intent.ACTION_DATE_CHANGED.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a)
                    || Intent.ACTION_TIMEZONE_CHANGED.equals(a) || Intent.ACTION_BOOT_COMPLETED.equals(a)) {
                AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
                int[] ids = mgr.getAppWidgetIds(new android.content.ComponentName(ctx, getClass()));
                if (ids != null && ids.length > 0) onUpdate(ctx, mgr, ids);
            }
        } catch (Throwable ignored) {
        }
    }
}
