package __APP_ID__;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** লম্বা উইজেট: ৮টি প্যাডের লোগো এক সারিতে — যেটিতে ট্যাপ, সরাসরি সেই প্যাডে। ক্যালেন্ডার-লোগোতে আজকের বার-তারিখ। */
public class WidgetBar extends AppWidgetProvider {

    private static final int[] IMG_IDS = {
            R.id.wb_0, R.id.wb_1, R.id.wb_2, R.id.wb_3, R.id.wb_4, R.id.wb_5, R.id.wb_6, R.id.wb_7, R.id.wb_8, R.id.wb_9
    };

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) {
            try {
                mgr.updateAppWidget(id, build(ctx));
            } catch (Throwable ignored) {
            }
        }
    }

    private RemoteViews build(Context ctx) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_bar);
        java.util.Calendar now = PadWidgets.now();
        for (int i = 0; i < PadWidgets.PADS.length && i < IMG_IDS.length; i++) {
            PadWidgets.bindLogo(ctx, rv, IMG_IDS[i], PadWidgets.PADS[i], now);
        }
        return rv;
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        try {
            String a = intent == null ? null : intent.getAction();
            if (a == null) return;
            if (Intent.ACTION_DATE_CHANGED.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a)
                    || Intent.ACTION_TIMEZONE_CHANGED.equals(a) || Intent.ACTION_BOOT_COMPLETED.equals(a)) {
                AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
                int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, WidgetBar.class));
                if (ids != null && ids.length > 0) onUpdate(ctx, mgr, ids);
            }
        } catch (Throwable ignored) {
        }
    }
}
