package __APP_ID__;

/** "med" প্যাডের উইজেট */
public class WidgetMed extends PadWidgetBase {
    @Override
    protected String pad() {
        return "med";
    }
}
