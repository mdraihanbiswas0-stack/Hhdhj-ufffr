package __APP_ID__;

/** "ear" (ইয়ার-ফ্লো রেকর্ডার) প্যাডের উইজেট */
public class WidgetEar extends PadWidgetBase {
    @Override
    protected String pad() {
        return "ear";
    }
}
