package __APP_ID__;

/** "biz" প্যাডের উইজেট */
public class WidgetBiz extends PadWidgetBase {
    @Override
    protected String pad() {
        return "biz";
    }
}
