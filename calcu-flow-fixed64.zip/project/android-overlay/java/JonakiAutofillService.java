package __APP_ID__;

import android.app.PendingIntent;
import android.app.assist.AssistStructure;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.CancellationSignal;
import android.service.autofill.AutofillService;
import android.service.autofill.Dataset;
import android.service.autofill.FillCallback;
import android.service.autofill.FillContext;
import android.service.autofill.FillRequest;
import android.service.autofill.FillResponse;
import android.service.autofill.SaveCallback;
import android.service.autofill.SaveInfo;
import android.service.autofill.SaveRequest;
import android.text.InputType;
import android.util.Pair;
import android.view.View;
import android.view.autofill.AutofillId;
import android.widget.RemoteViews;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * কী-ফ্লো অটোফিল সার্ভিস: অন্য অ্যাপ/ব্রাউজারের লগইন ফর্মে ইউজারনেম-পাসওয়ার্ড বসায়।
 * প্রতিবার ফোনের স্ক্রিন-লক (পিন/প্যাটার্ন/ফিঙ্গারপ্রিন্ট) দিয়ে যাচাই করে তবেই তথ্য দেয়।
 */
public class JonakiAutofillService extends AutofillService {

    private static final AtomicInteger REQ = new AtomicInteger(1000);

    private static class Parsed {
        AutofillId userId;
        AutofillId passId;
        AutofillId lastText;
        String pkg;
        String web;
        ArrayList<AutofillId> passIds = new ArrayList<>();
        boolean reg;          // নতুন অ্যাকাউন্ট/নতুন পাসওয়ার্ডের ফর্ম মনে হচ্ছে
        String userVal = "";
        String passVal = "";
        String lastVal = "";
    }

    @Override
    public void onFillRequest(FillRequest request, CancellationSignal cancel, FillCallback callback) {
        try {
            List<FillContext> ctx = request.getFillContexts();
            if (ctx == null || ctx.isEmpty()) {
                callback.onSuccess(null);
                return;
            }
            AssistStructure st = ctx.get(ctx.size() - 1).getStructure();
            Parsed p = new Parsed();
            for (int i = 0; i < st.getWindowNodeCount(); i++) {
                parse(st.getWindowNodeAt(i).getRootViewNode(), p, 0);
            }
            if (p.passId == null && p.userId == null) {
                callback.onSuccess(null);
                return;
            }
            if (getPackageName().equals(p.pkg)) {
                callback.onSuccess(null);
                return;
            }
            List<AutofillStore.Entry> all = AutofillStore.load(this);
            if (p.passId == null && all.isEmpty()) {
                callback.onSuccess(null);
                return;
            }
            List<AutofillStore.Entry> matches = match(all, p);
            FillResponse.Builder fr = new FillResponse.Builder();
            int n = 0;
            // নতুন পাসওয়ার্ডের ঘরে (রেজিস্ট্রেশন/পাসওয়ার্ড বদল) বা সংরক্ষিত লগইন না থাকলে — শক্তিশালী পাসওয়ার্ড সাজেশন সবার আগে
            if (p.passId != null && (p.reg || matches.isEmpty())) {
                fr.addDataset(dataset("✨ শক্তিশালী পাসওয়ার্ড সাজেস্ট করুন", "কী-ফ্লো একটি নতুন পাসওয়ার্ড বানিয়ে দেবে ও সেভ রাখবে", suggestSender(p)));
            }
            if (!(p.reg && p.passId != null && matches.isEmpty())) {
                for (AutofillStore.Entry e : matches) {
                    if (n >= 4) break;
                    String sub = e.user.length() > 0 ? e.user : AutofillStore.hostOf(e.url);
                    fr.addDataset(dataset(e.title.length() > 0 ? e.title : sub, sub, sender(e.id, p)));
                    n++;
                }
                if (!all.isEmpty()) fr.addDataset(dataset("🔐 কী-ফ্লো ভল্ট", "সব লগইন থেকে বাছুন", sender(null, p)));
            }
            // লগইন/রেজিস্ট্রেশনের পর "কী-ফ্লোতে সেভ করবেন?" — অনুমতি নিয়ে নতুন/বদলানো পাসওয়ার্ড সেভ
            if (p.passId != null) {
                int types = SaveInfo.SAVE_DATA_TYPE_PASSWORD | (p.userId != null ? SaveInfo.SAVE_DATA_TYPE_USERNAME : 0);
                SaveInfo.Builder sb = new SaveInfo.Builder(types, new AutofillId[]{p.passId});
                if (p.userId != null) sb.setOptionalIds(new AutofillId[]{p.userId});
                sb.setFlags(SaveInfo.FLAG_SAVE_ON_ALL_VIEWS_INVISIBLE);
                fr.setSaveInfo(sb.build());
            }
            callback.onSuccess(fr.build());
        } catch (Throwable t) {
            callback.onFailure("autofill error");
        }
    }

    @Override
    public void onSaveRequest(SaveRequest request, SaveCallback callback) {
        try {
            List<FillContext> ctx = request.getFillContexts();
            if (ctx == null || ctx.isEmpty()) {
                callback.onSuccess();
                return;
            }
            Parsed p = new Parsed();
            for (FillContext fc : ctx) {
                AssistStructure st = fc.getStructure();
                for (int i = 0; i < st.getWindowNodeCount(); i++) parse(st.getWindowNodeAt(i).getRootViewNode(), p, 0);
            }
            if (p.passVal.length() > 0 && !getPackageName().equals(p.pkg)) {
                AutofillStore.Entry e = new AutofillStore.Entry();
                boolean web = p.web != null && p.web.length() > 0;
                e.url = web ? "https://" + p.web : "app://" + (p.pkg == null ? "" : p.pkg);
                e.title = web ? AutofillStore.hostOf(e.url) : appLabel(p.pkg);
                e.user = p.userVal.length() > 0 ? p.userVal : p.lastVal;
                e.pass = p.passVal;
                AutofillStore.upsertPending(this, e);
                final String t = e.title;
                new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        android.widget.Toast.makeText(JonakiAutofillService.this, "🔐 কী-ফ্লোতে সেভ হয়েছে: " + t + " (অ্যাপ খুললে ভল্টে যুক্ত হবে)", android.widget.Toast.LENGTH_LONG).show();
                    }
                });
            }
            callback.onSuccess();
        } catch (Throwable t) {
            callback.onFailure("save failed");
        }
    }

    private String appLabel(String pkg) {
        if (pkg == null || pkg.length() == 0) return "অ্যাপ";
        try {
            return String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)));
        } catch (Throwable t) {
            return pkg;
        }
    }

    private IntentSender suggestSender(Parsed p) {
        Intent i = new Intent(this, AutofillAuthActivity.class);
        i.putExtra("suggest", true);
        i.putParcelableArrayListExtra("passes", p.passIds);
        if (p.userId != null) i.putExtra("user", p.userId);
        i.putExtra("pkg", p.pkg == null ? "" : p.pkg);
        i.putExtra("web", p.web == null ? "" : p.web);
        int flags = PendingIntent.FLAG_CANCEL_CURRENT;
        if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
        return PendingIntent.getActivity(this, REQ.incrementAndGet(), i, flags).getIntentSender();
    }

    @SuppressWarnings("deprecation")
    private Dataset dataset(String title, String sub, IntentSender sender) {
        RemoteViews rv = new RemoteViews(getPackageName(), R.layout.autofill_item);
        rv.setTextViewText(R.id.af_title, title);
        rv.setTextViewText(R.id.af_sub, sub);
        Dataset.Builder b = new Dataset.Builder(rv);
        b.setAuthentication(sender);
        return b.build();
    }

    private IntentSender sender(String entryId, Parsed p) {
        Intent i = new Intent(this, AutofillAuthActivity.class);
        if (entryId != null) i.putExtra("entry", entryId);
        if (p.userId != null) i.putExtra("user", p.userId);
        if (p.passId != null) i.putExtra("pass", p.passId);
        int flags = PendingIntent.FLAG_CANCEL_CURRENT;
        if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
        return PendingIntent.getActivity(this, REQ.incrementAndGet(), i, flags).getIntentSender();
    }

    /* ---------- ফর্মের ফিল্ড খোঁজা ---------- */

    private void parse(AssistStructure.ViewNode n, Parsed p, int depth) {
        if (n == null || depth > 60) return;
        if (p.pkg == null) {
            String ip = n.getIdPackage();
            if (ip != null && ip.length() > 0) p.pkg = ip;
        }
        String wd = n.getWebDomain();
        if (wd != null && wd.length() > 0) p.web = wd;

        AutofillId id = n.getAutofillId();
        if (id != null && n.getAutofillType() == View.AUTOFILL_TYPE_TEXT) {
            boolean isPass = false;
            boolean isUser = false;
            boolean newHint = false;
            String[] hints = n.getAutofillHints();
            if (hints != null) {
                for (String h : hints) {
                    if (h == null) continue;
                    String hl = h.toLowerCase(Locale.ROOT);
                    if (hl.contains("new") && hl.contains("pass")) { isPass = true; newHint = true; }
                    else if (View.AUTOFILL_HINT_PASSWORD.equals(h)) isPass = true;
                    else if (View.AUTOFILL_HINT_USERNAME.equals(h)
                            || View.AUTOFILL_HINT_EMAIL_ADDRESS.equals(h)
                            || View.AUTOFILL_HINT_PHONE.equals(h)) isUser = true;
                }
            }
            int it = n.getInputType();
            if ((it & InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT) {
                int v = it & InputType.TYPE_MASK_VARIATION;
                if (v == InputType.TYPE_TEXT_VARIATION_PASSWORD
                        || v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                        || v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD) isPass = true;
                else if (v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                        || v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS) isUser = true;
            } else if ((it & InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER) {
                if ((it & InputType.TYPE_MASK_VARIATION) == InputType.TYPE_NUMBER_VARIATION_PASSWORD) isPass = true;
            }
            android.view.ViewStructure.HtmlInfo hi = n.getHtmlInfo();
            if (hi != null) {
                String tag = hi.getTag();
                if (tag != null && "input".equalsIgnoreCase(tag) && hi.getAttributes() != null) {
                    for (Pair<String, String> a : hi.getAttributes()) {
                        if (a == null || a.first == null || a.second == null) continue;
                        String k = a.first.toLowerCase(Locale.ROOT);
                        String val = a.second.toLowerCase(Locale.ROOT);
                        if ("type".equals(k)) {
                            if ("password".equals(val)) isPass = true;
                            else if ("email".equals(val) || "tel".equals(val)) isUser = true;
                        } else if ("autocomplete".equals(k)) {
                            if (val.contains("new-password")) { isPass = true; newHint = true; }
                            else if (val.contains("password")) isPass = true;
                            else if (val.contains("username") || val.contains("email")) isUser = true;
                        } else if ("name".equals(k) || "id".equals(k)) {
                            if (val.contains("user") || val.contains("email") || val.contains("login")) isUser = true;
                        }
                    }
                }
            }
            String ide = n.getIdEntry();
            String hintTxt = n.getHint() == null ? "" : n.getHint().toLowerCase(Locale.ROOT);
            if (ide != null) {
                String l = ide.toLowerCase(Locale.ROOT);
                if (l.contains("pass")) isPass = true;
                else if (l.contains("user") || l.contains("email") || l.contains("login")) isUser = true;
            }
            boolean isText = (it & InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT || n.getHtmlInfo() != null;
            String val = "";
            try {
                android.view.autofill.AutofillValue av = n.getAutofillValue();
                if (av != null && av.isText()) val = String.valueOf(av.getTextValue());
            } catch (Throwable ignored) {
            }
            if (isPass) {
                p.passIds.add(id);
                // ২য় পাসওয়ার্ড-ঘর (কনফার্ম) বা "নতুন/কনফার্ম/রেজিস্টার" ইঙ্গিত = রেজিস্ট্রেশন/পাসওয়ার্ড বদলের ফর্ম
                String ll = (ide == null ? "" : ide.toLowerCase(Locale.ROOT)) + " " + hintTxt;
                if (newHint || p.passIds.size() > 1 || ll.contains("confirm") || ll.contains("repeat") || ll.contains("retype")
                        || ll.contains("new") || ll.contains("signup") || ll.contains("register") || ll.contains("create")
                        || ll.contains("নতুন") || ll.contains("নিশ্চিত")) p.reg = true;
                if (p.passVal.length() == 0 && val.length() > 0) p.passVal = val;
                if (p.passId == null) {
                    p.passId = id;
                    if (p.userId == null && p.lastText != null) { p.userId = p.lastText; p.userVal = p.lastVal; }
                }
            } else if (isUser) {
                if (p.userId == null) { p.userId = id; p.userVal = val; }
            } else if (isText && p.passId == null) {
                p.lastText = id;
                p.lastVal = val;
            }
        }
        int cc = n.getChildCount();
        for (int i = 0; i < cc; i++) parse(n.getChildAt(i), p, depth + 1);
    }

    /* ---------- সাইট/অ্যাপ মেলানো ---------- */

    private List<AutofillStore.Entry> match(List<AutofillStore.Entry> all, Parsed p) {
        List<AutofillStore.Entry> out = new ArrayList<>();
        String web = p.web == null ? "" : p.web.toLowerCase(Locale.ROOT);
        if (web.startsWith("www.")) web = web.substring(4);
        String pkg = p.pkg == null ? "" : p.pkg.toLowerCase(Locale.ROOT);
        String[] toks = pkg.split("\\.");
        for (AutofillStore.Entry e : all) {
            String host = AutofillStore.hostOf(e.url);
            boolean ok = false;
            if (web.length() > 0 && host.length() > 0) {
                ok = web.equals(host) || web.endsWith("." + host) || host.endsWith("." + web);
            }
            if (!ok && web.length() == 0 && pkg.length() > 0) {
                String label = host;
                int d = host.lastIndexOf('.');
                if (d > 0) {
                    String head = host.substring(0, d);
                    int d2 = head.lastIndexOf('.');
                    label = d2 >= 0 ? head.substring(d2 + 1) : head;
                }
                String title = e.title == null ? "" : e.title.toLowerCase(Locale.ROOT);
                for (String t : toks) {
                    if (t.length() < 4 || "android".equals(t) || "mobile".equals(t) || "google".equals(t) && !"google".equals(label)) continue;
                    if ("katana".equals(t) || "orca".equals(t)) continue;
                    if ((label.length() >= 4 && t.contains(label)) || (label.length() >= 4 && label.contains(t))
                            || (title.length() >= 4 && title.contains(t))) {
                        ok = true;
                        break;
                    }
                }
                // ফেসবুক ইত্যাদির প্যাকেজে "facebook" শব্দটা থাকে — তা উপরের শর্তেই ধরা পড়ে
                if (!ok && label.length() >= 4 && pkg.contains(label)) ok = true;
            }
            if (ok) out.add(e);
        }
        return out;
    }
}
