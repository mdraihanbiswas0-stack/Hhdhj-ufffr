package __APP_ID__;

/** "kf" প্যাডের উইজেট */
public class WidgetKf extends PadWidgetBase {
    @Override
    protected String pad() {
        return "kf";
    }
}
